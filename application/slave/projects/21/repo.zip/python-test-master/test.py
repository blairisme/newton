

a = 10
b = 5
c = a + b
print("sum= ", str(c))